"%ProgramFiles%\Windows Defender\MpCmdRun.exe" -Restore -FilePath "C:\Users\%UserName%\Desktop\RokPCAuto\RokPCAuto.exe"

powershell.exe -NoProfile -Command "Add-MpPreference -ExclusionPath 'C:\Users\%UserName%\Desktop\RokPCAuto'"